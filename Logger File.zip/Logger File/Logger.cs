﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 ** What is this module?
 *      This is implementation of Logger Utility for C# Environment.
 * 
 ** What is need of this Logger Class?
 *      This class helps to get track of all the logs during excecution of any module(s)/project(s).
 *      While excecution of complex code, it always difficult to debug for any bug(s) and issue(s) or keeping track of excecution.
 *      All the Exception related info as well as all the messages will be available in which User/Programmer(s) want to track.
 * 
 ** How to use this Logger Class?
 *      Please follow below steps:
 *          1. Paste this class file(.cs file) to your solution.
 *          2. Change namespace of this class, change to <your_module_namespace>.
 *          3. There is 2 way to access this:
 *              a. Write Message in your log file:
 *                  Logger.LogFileWrite("This is message.", <provide_full_log_path>); 
 *              b. Write Exception in your log file:
 *                  Logger.Log(<exception_object>, <provide_full_log_path>);
 *          4. Provide file path in which log will be appended.
 *              e.g. 
 *                  #region Variable Declaration
 *                  static string logPath = @"C:\User\Desktop\"; <provide_your_path_in_your_module>.
 *                  static string logFileName = "logs_dd_mm_yyyy.log"; <provide_your_log_file_name_in_your_module>.
 *                  logPath = logPath + logFileName;
 *                  #endregion
 *          5. Write Log statement in your code to track details use your log file path variable with this.
 *              e.g.
 *                  Logger.LogFileWrite("Main method Started", logPath);
 *                  Logger.LogFileWrite("Variable value: " + "value1", logPath);
 *                  Logger.LogFileWrite("Main method Ended", logPath);
 *                  Logger.LogFileWrite("Variable value after method called: " + "value2", logPath);
 *          6. Write Log statement with Exception in catch block of your code.
 *              e.g.
 *                  Logger.Log(exception.Message, logPath);
 *                  Logger.Log(exception.ToString(), logPath);
 *                  Logger.Log("Exception caught in demo catch block :: ", logPath);
 *          7. Observe the file!
 * 
 ** Can anyone modify this Class?
 *      Ofcourse, Anyone can modify for custom logics.
 * 
 ** Is this Industrial Standard?
 *      No, But Industries can use this as their standard.
 * 
 ** Version: 1.0
 * 
 ** Author: Bhargav Rathod, [bhargavrathod98@gmail.com]
 * 
 ** Limitations:
 *      1. Only works with C# code and .Net Environment.
 *      2. Work as same logic, Not Intelligent
 * 
 ** Future Extention:
 *      1. Generic for all Language
 *      2. Smart Features
 *      
 ** Contact Details:
 *      For any of your concern you can reach out to me.
 *          Bhargav Rathod
 *          bhargavrathod98@gmail.com
 *          bhargavrathod98@yahoo.com
 *          India
 *      
 ** Remarks
 *      Happy Coding :)
 */

namespace LoggingUtility //change namespace, modify your module's namespace here 
{
    /// <summary>
    /// Logger Class for generating Logs
    /// </summary>
    public static class Logger
    {
        /// <summary>
        /// This method prepare ErrorMessage based on Exception object
        /// </summary>
        /// <param name="serviceException"></param>
        /// <param name="filePath"></param>
        public static void Log(Exception serviceException, string filePath)
        {
            StringBuilder messageBuilder = new StringBuilder();
            try
            {
                messageBuilder.Append(" The Exception is: ");
                if (serviceException.InnerException != null && !string.IsNullOrEmpty(serviceException.InnerException.Message))
                {
                    if (serviceException.InnerException.Message.Trim().ToLower().Contains("service unavailable") ||
                    serviceException.InnerException.Message.Trim().ToLower().Contains("target machine actively refused") ||
                    serviceException.InnerException.Message.Trim().ToLower().Contains("unable to connect"))
                    {
                        messageBuilder.Append(serviceException.InnerException.ToString());
                    }
                    else
                    {
                        messageBuilder.Append(" Exception :: " + serviceException.ToString());
                        if (serviceException.InnerException != null)
                        {
                            messageBuilder.Append(" Inner Exception :: " + serviceException.InnerException.ToString());

                        }
                    }
                }
                else if (serviceException.Message.Trim().ToLower().Contains("service unavailable") ||
                    serviceException.Message.Trim().ToLower().Contains("target machine actively refused") ||
                    serviceException.Message.Trim().ToLower().Contains("unable to connect"))
                {
                    messageBuilder.Append(" Exception :: " + serviceException.Message);
                }
                else
                {
                    messageBuilder.Append(" Exception :: " + serviceException.ToString());
                    if(serviceException.InnerException != null)
                    {
                        messageBuilder.Append(" Inner Exception :: " + serviceException.InnerException.ToString());
                    }
                }

                LogFileWrite(messageBuilder.ToString(), filePath);
            }
            catch (Exception ex)
            {
                messageBuilder.Append(" Exception :: " + "Unknown exception caught!");
            }
            finally
            {
                if(messageBuilder != null)
                {
                    messageBuilder.Clear();
                    messageBuilder = null;
                }
            }
        }

        /// <summary>
        /// This method writes logs in file with message parameter
        /// </summary>
        /// <param name="message"></param>
        /// <param name="filepath"></param>
        public static void LogFileWrite(string message, string filepath)
        {
            FileStream fileStream = null;
            StreamWriter streamWriter = null;
            try
            {
                message = DateTime.Now.ToString() + " : " + message;
                string logFilePath = filepath;
                if (string.IsNullOrEmpty(logFilePath.Trim())) return;

                #region Create Directory and/or File if it does not exists

                FileInfo logFileInfo = new FileInfo(logFilePath);
                DirectoryInfo logDirectoryInfo = new DirectoryInfo(logFileInfo.DirectoryName);
                if (!logDirectoryInfo.Exists) logDirectoryInfo.Create();
                if (!logFileInfo.Exists) fileStream = logFileInfo.Create();
                else fileStream = new FileStream(logFilePath, FileMode.Append);

                #endregion

                streamWriter = new StreamWriter(fileStream);
                streamWriter.WriteLine(message);

            }
            catch (Exception ex)
            {
                // do - nothing!
            }
            finally
            {
                if (streamWriter != null)
                {
                    streamWriter.Close();
                }
                if (fileStream != null)
                {
                    fileStream.Close();
                }
                
            }
        }
        
    }
}
