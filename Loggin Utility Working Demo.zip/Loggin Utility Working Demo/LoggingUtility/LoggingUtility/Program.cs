﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoggingUtility
{
    class Program
    {
        #region Variable Declaration
        static string logPath = @"C:\Users\Bhargav Rathod\Desktop\LoggingUtilityDemo\";
        static string logFileName = "logs_" + DateTime.Now.ToString("MM") + "_" + DateTime.Now.ToString("dd") + "_" +  DateTime.Now.ToString("yyyy") + ".log";
        #endregion
        static void Main(string[] args)
        {
            logPath = logPath + logFileName;
            Logger.LogFileWrite("Main Method Started", logPath);
            try
            {
                Logger.LogFileWrite("Before TestMethod called", logPath);
                TestMethod();
                Logger.LogFileWrite("After TestMethod called", logPath);
            }
            catch (Exception ex)
            {
                Logger.Log(ex, logPath);
            }
            finally
            {
                Logger.LogFileWrite("Main Method Ended", logPath);
            }
        }

        public static void TestMethod()
        {
            Logger.LogFileWrite("TestMethod Started", logPath);
            try
            {
                float number1 = 10;
                Logger.LogFileWrite("Number1 is: " + number1, logPath);
                float number2 = 0;
                Logger.LogFileWrite("Number2 is: " + number1, logPath);
                float result = number1 / number2;
                Logger.LogFileWrite("Result is:" + result.ToString(), logPath);
                int[] a = new int[3];

                a[0] = 1;
                Logger.LogFileWrite("Curent Status of Array:" + a.ToString(), logPath);
                a[1] = 2;
                Logger.LogFileWrite("Curent Status of Array:" + a.ToString(), logPath);
                a[2] = 3;
                Logger.LogFileWrite("Curent Status of Array:" + a.ToString(), logPath);
                a[3] = 4;
                Logger.LogFileWrite("Curent Status of Array:" + a.ToString(), logPath);

            }
            catch(Exception ex)
            {
                Logger.Log(ex, logPath);
            }
            finally
            {
                Logger.LogFileWrite("Test Method Ended", logPath);
            }
        }
    }
}

/*
 Please find demo logs of ths code:
06-May-20 4:39:39 PM : Main Method Started
06-May-20 4:39:40 PM : Before TestMethod called
06-May-20 4:39:43 PM : TestMethod Started
06-May-20 4:39:44 PM : Number1 is: 10
06-May-20 4:39:45 PM : Number2 is: 10
06-May-20 4:39:45 PM : Result is:∞
06-May-20 4:39:48 PM : Curent Status of Array:System.Int32[]
06-May-20 4:39:49 PM : Curent Status of Array:System.Int32[]
06-May-20 4:39:50 PM : Curent Status of Array:System.Int32[]
06-May-20 4:39:53 PM :  The Exception is:  Exception :: System.IndexOutOfRangeException: Index was outside the bounds of the array.
   at LoggingUtility.Program.TestMethod() in C:\Users\Bhargav Rathod\Desktop\LoggingUtility\LoggingUtility\Program.cs:line 54
06-May-20 4:39:54 PM : Test Method Ended
06-May-20 4:39:55 PM : After TestMethod called
06-May-20 4:39:57 PM : Main Method Ended
*/
